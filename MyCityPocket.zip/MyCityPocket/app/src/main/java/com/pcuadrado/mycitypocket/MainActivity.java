package com.pcuadrado.mycitypocket;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.pcuadrado.mycitypocket.Prevision;
import com.pcuadrado.mycitypocket.R;
import com.pcuadrado.mycitypocket.db.DbHelper;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText textCity, textCountry;
    private TextView txt_feels, txt_clouds, txt_wind, temp_weather, temp_max_min, presion, description, textoCabecera, textPais;
    private ImageView imagen;
    private CardView cardView;
    private Button botonForecast;
    private ImageButton botonFav;
    private ListView listView;
    private ArrayList<Prevision> listaPrevision;
    private ArrayAdapter<Prevision> adaptadorPrevision;
    Double longitud, latitud;
    View view;
    String apiKey = "75295f27a9ad64994c15cd06c6965a44";
    String url = "http://api.openweathermap.org/data/2.5/weather?q=";
    String dbNombre, dbPais;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instancias();
        consultar();
        getWeatherDetails(view);


        botonFav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarFav();

            }
        });

        botonForecast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent forecastActivity = new Intent(MainActivity.this, ForecastActivity.class);

                forecastActivity.putExtra("longitud", longitud);
                forecastActivity.putExtra("latitud", latitud);

                startActivity(forecastActivity);
            }
        });

    }

    private void consultar() {

        DbHelper con = new DbHelper(this, "bd_favoritos", null, 1);
        SQLiteDatabase db = con.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM favoritos", null);


        while(cursor.moveToNext()) {
            String nombre = cursor.getString(0);
            String pais = cursor.getString(1);
            textCity.setText(nombre);
            Log.v("cursor", nombre +", "+ pais);
        }

    }

    private void registrarFav() {

        DbHelper con = new DbHelper(this, "bd_favoritos", null, 1);
        SQLiteDatabase db = con.getWritableDatabase();
        db.execSQL("DELETE FROM favoritos");
        ContentValues values = new ContentValues();
        values.put("nombre", textoCabecera.getText().toString());
        values.put("pais", textPais.getText().toString());

        Long resultado = db.insert("favoritos", "nombre", values);
        Toast.makeText(getApplicationContext(), "Nueva localización favorita", Toast.LENGTH_SHORT).show();
        Log.v("registro", resultado.toString());

        db.close();
    }

    private void instancias() {

        textoCabecera = findViewById(R.id.cabecera);
        textCity = findViewById(R.id.text_city);
        textCountry = findViewById(R.id.text_country);
        textPais = findViewById(R.id.text_pais);
        txt_clouds = findViewById(R.id.clouds);
        txt_feels = findViewById(R.id.feels_like);
        txt_wind = findViewById(R.id.wind);
        temp_max_min = findViewById(R.id.temp_max_min);
        description = findViewById(R.id.description);
        presion = findViewById(R.id.presion);
        temp_weather = findViewById(R.id.temp_weather);
        imagen = findViewById(R.id.image);

        botonForecast = findViewById(R.id.forecastButton);
        botonFav = findViewById(R.id.botonFav);
        cardView = findViewById(R.id.cardview);

    }

    public void getWeatherDetails(View view) {

        botonForecast.setVisibility(view.VISIBLE);
        cardView.setVisibility(view.VISIBLE);

        String tempUrl = "";
        String city = textCity.getText().toString().trim();
        String country = textCountry.getText().toString().trim();


        if (city.equals("")){
            Toast.makeText(getApplicationContext(), "Debe rellenar el campo", Toast.LENGTH_SHORT).show();
        } else {
            if (!country.equals("")){
                tempUrl = url + city + "," + country + "&appid=" + apiKey;
            } else {
                tempUrl = url + city + "&&units=metric&appid=" + apiKey;
            }
            StringRequest stringRequest = new StringRequest(Request.Method.POST, tempUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("bycity", response);

                    String output = "";
                    try {

                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray jsonArray = jsonObject.getJSONArray("weather");
                        JSONObject jsonObjectWeather = jsonArray.getJSONObject(0);
                        String descr = jsonObjectWeather.getString("description");
                        String main = jsonObjectWeather.getString("main");
                        JSONObject jsonObjectMain = jsonObject.getJSONObject("main");
                        JSONObject jObjectcoordenadas = jsonObject.getJSONObject("coord");
                        double lat = jObjectcoordenadas.getDouble("lat");
                        double lon = jObjectcoordenadas.getDouble("lon");
                        double temp = jsonObjectMain.getDouble("temp");
                        double temp_min = jsonObjectMain.getDouble("temp_min");
                        double temp_max = jsonObjectMain.getDouble("temp_max");
                        double feels_like = jsonObjectMain.getDouble("feels_like");
                        float pressure = jsonObjectMain.getInt("pressure");
                        int humidity = jsonObjectMain.getInt("humidity");
                        JSONObject jsonObjectWind = jsonObject.getJSONObject("wind");
                        String wind = jsonObjectWind.getString("speed");
                        JSONObject jsonObjectClouds = jsonObject.getJSONObject("clouds");
                        String clouds = jsonObjectClouds.getString("all");
                        JSONObject jsonObjectSys = jsonObject.getJSONObject("sys");
                        String country_name = jsonObjectSys.getString("country");
                        String city_name = jsonObject.getString("name");
                        String city_id = jsonObject.getString("id");

                        latitud = lat;
                        longitud = lon;

                        temp_weather.setText((temp) + " ºC");
                        textoCabecera.setText(city_name);
                        textPais.setText(country_name);

                        txt_feels.setText(temp_max + " ºC");
                        txt_wind.setText(wind + " m/s");
                        txt_clouds.setText(clouds + " %");
                        temp_max_min.setText(temp_min + " ºC");
                        presion.setText(main);
                        description.setText(humidity + "%");

                        output += city_name + "(" + country_name + ")" +
                                "\n" + "Feels like: " + feels_like +
                                "\n" + "Humidity: " + humidity + "%" +
                                "\n" + "Description: " + description +
                                "\n" + "Wind: " + wind + " m/s" +
                                "\n" + "Clouds: " + clouds + " %" +
                                "\n" + "Pressure" + pressure + " hPa";
                        Log.d("resultado", output);

                        if (main.equals("Clouds")){
                            imagen.setImageResource(R.drawable.nube);
                        }
                        if (main.equals("Clear")){
                            imagen.setImageResource(R.drawable.sun);
                        }
                        if (main.equals("Rain")){
                            imagen.setImageResource(R.drawable.lluvia);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                    Log.v("mensaje", error.toString());
                }
            });

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            requestQueue.add(stringRequest);

        }
    }

}