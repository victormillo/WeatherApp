package com.pcuadrado.mycitypocket;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ForecastActivity extends AppCompatActivity {



    private Button botonBack;
    private ListView listView;
    private ArrayList<Prevision> listaPrevision;
    private ArrayAdapter<Prevision> adaptadorPrevision;
    private AdaptadorWeather adaptadorWeather;
    TextView descripcionText, cloudText, humText, windText, tempMin, tempMax;
    private Double lat, lon, windDialog, humidityDialog, cloudsDialog;
    String apiKey = "75295f27a9ad64994c15cd06c6965a44";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forecast);
        instancias();

        Bundle recibirCoord = getIntent().getExtras();
        lon = recibirCoord.getDouble("longitud");
        lat = recibirCoord.getDouble("latitud");
        getWeatherForecast(lat, lon);

        botonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ForecastActivity.this, MainActivity.class));

            }
        });
    }

    private void instancias() {
        botonBack = findViewById(R.id.weatherButton);
        listView = findViewById(R.id.listForecast);
        listaPrevision = new ArrayList();
        //adaptadorPrevision = new ArrayAdapter(getApplication(), android.R.layout.simple_list_item_1 ,listaPrevision);
        adaptadorWeather = new AdaptadorWeather(getApplicationContext(), listaPrevision);



    }

    public void getWeatherForecast(double lat, double lon) {


        String url = "https://api.openweathermap.org/data/2.5/onecall?lat="+lat+"&lon="+lon+"&exclude=hourly,current&appid="+apiKey;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("forecast", response);

                String output = "";
                try {

                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray current = jsonObject.getJSONArray("daily");
                    Log.d("current", current.toString());
                    String timezone = jsonObject.getString("timezone");

                    for (int i = 1; i < current.length(); i++){
                        JSONObject itemDate = current.getJSONObject(i);
                        JSONObject itemTemp = current.getJSONObject(i);
                        JSONObject itemIcon = current.getJSONObject(i);
                        JSONObject itemClouds = current.getJSONObject(i);
                        JSONObject itemWind = current.getJSONObject(i);

                        Log.v("contestacion", String.valueOf(i));
                        Long date = itemDate.getLong("dt");
                        JSONObject jTemp = itemTemp.getJSONObject("temp");
                        Double clouds = itemClouds.getDouble("clouds");
                        Double wind_speed = itemClouds.getDouble("wind_speed");
                        Double humidity = itemClouds.getDouble("humidity");
                        Double temp = jTemp.getDouble("day");
                        Double tempMin = jTemp.getDouble("min");
                        Double tempMax = jTemp.getDouble("max");
                        String main = "";

                        windDialog = wind_speed;
                        humidityDialog = humidity;
                        cloudsDialog = clouds;

                        //adaptadorEquipos.addPartido(partido);
                        listaPrevision.add(new Prevision(date, timezone, "icon", temp, main, tempMin, tempMax));
                        Log.d("lista", listaPrevision.toString());

                    }

                    listView.setAdapter(adaptadorWeather);
                    adaptadorWeather.notifyDataSetChanged();
                    listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            Prevision prevision = listaPrevision.get(position);
                            Log.d("itemlist", prevision.toString());
                            //Toast.makeText(getApplicationContext(), prevision.toString(), Toast.LENGTH_SHORT).show();

                            AlertDialog.Builder builder = new AlertDialog.Builder(ForecastActivity.this);
                            LayoutInflater layoutInflater = getLayoutInflater();
                            view = layoutInflater.inflate(R.layout.item_dialogo, null);
                            builder.setView(view);

                            descripcionText = view.findViewById(R.id.descriptionText);
                            cloudText = view.findViewById(R.id.cloudsText);
                            windText = view.findViewById(R.id.windText);
                            humText = view.findViewById(R.id.humedadText);

                            descripcionText.setText(timezone);
                            cloudText.setText("Clouds: " + cloudsDialog + " %");
                            windText.setText("Wind: " + windDialog + " Km/h");
                            humText.setText("Humidity: " + humidityDialog + " %");

                            final AlertDialog dialog = builder.create();
                            dialog.show();

                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString().trim(), Toast.LENGTH_SHORT).show();
                Log.v("mensaje", error.toString());
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);


    }


}