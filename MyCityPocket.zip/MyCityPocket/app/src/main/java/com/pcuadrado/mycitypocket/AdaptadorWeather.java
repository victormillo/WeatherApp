package com.pcuadrado.mycitypocket;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class AdaptadorWeather extends ArrayAdapter<Prevision> {

    private Context context;
    private List<Prevision> listaPrevision;

    public AdaptadorWeather(@NonNull Context context, @NonNull List<Prevision> listaPrevision) {
        super(context, 0, listaPrevision);
        this.context = context;
        this.listaPrevision = listaPrevision;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(R.layout.item_weather, parent, false);

        TextView fecha = convertView.findViewById(R.id.txt_fecha);
        TextView tempMin = convertView.findViewById(R.id.temp_min);
        TextView tempMax = convertView.findViewById(R.id.temp_max);
        ImageView icon = convertView.findViewById(R.id.icon_weather);

        Prevision prevision = listaPrevision.get(position);
        double temperatura = (prevision.getTemp() - 273.15);
        double temperaturaMin = (prevision.getTempMin() - 273.15);
        double temperaturaMax = (prevision.getTempMax() - 273.15);
        String main = prevision.getMain();
        Log.v("main", main);

        String tempMinRedondeada=String.valueOf(temperaturaMin);
        String tempMaxRedondeada=String.valueOf(temperaturaMax);
        tempMinRedondeada = tempMinRedondeada.substring(0,4);
        tempMaxRedondeada = tempMaxRedondeada.substring(0,4);

        tempMin.setText(tempMinRedondeada+ " ºC");
        tempMax.setText(tempMaxRedondeada+ " ºC");

        /*Glide.with(context)
                .load("http://api.openweathermap.org/img/w/"+prevision.getIcon()+".png")
                .into(icon);*/

        if (temperatura < 35 && temperatura > 26){
            icon.setImageResource(R.drawable.sun);
        }
        if (temperatura < 26 && temperatura > 23){
            icon.setImageResource(R.drawable.nublado);
        }
        if (temperatura < 23 && temperatura > 15){
            icon.setImageResource(R.drawable.nube);
        }
        if (temperatura < 15 ){
            icon.setImageResource(R.drawable.lluvia);
        }

        Date datecita = new Date(prevision.getDate() * 1000);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        dateFormat.setTimeZone(TimeZone.getTimeZone(prevision.getTime_zone()));
        String date_formateada = dateFormat.format(datecita);
        fecha.setText(""+date_formateada);

        return convertView;
    }
}
